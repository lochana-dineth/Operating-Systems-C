//gcc 1.c -o 1 -l pthread to compile!
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <stdio.h>
#define NUM_THREADS 4
int shared=0;
pthread_mutex_t mutex=PTHREAD_MUTEX_INITIALIZER;


//Creating function to use the Pthreads!
void *func3(void* param) //Remember that it should be a pointer in order to use threads!
{
    pthread_mutex_lock(&mutex);
    for (int i=0; i<10000; i++)
    {
        shared=shared+i;
    }
    printf("Incremented by the Thread %d\n", shared);
    shared =0;
    pthread_mutex_unlock(&mutex);

}

int main()
{
    pthread_t threads[NUM_THREADS]; //Array of Threads!

    for (int i=0 ; i < NUM_THREADS ; i++)
    {
        pthread_create(&threads[i],'\0',func3,'\0');
    }

     for (int i=0 ; i < NUM_THREADS ; i++)
    {
        pthread_join(threads[i],'\0');
    }
    printf("Main Method is printig shared memory value %d\n", shared);
    exit(EXIT_SUCCESS);

    return 0;
}