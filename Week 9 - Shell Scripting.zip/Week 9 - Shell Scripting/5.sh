#!/bin/bash
# This program calculate the sum of 1 to 10
sum=0
for((n=1; n<=10; n++)) #for loop
do
 sum=$(expr $sum + $n)
done
echo "The sum of 1 to 10 is $sum"