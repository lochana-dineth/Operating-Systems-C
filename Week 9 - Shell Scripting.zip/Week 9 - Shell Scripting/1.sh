#chmod 755 1.bash
clear
echo "Knowledge is power!"
echo "Hello from Bash!!!"
