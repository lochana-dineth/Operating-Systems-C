#!/bin/bash
#!bash
# -eq for equal -gt for greater than -lt for less than
#If then in Bash
echo "Enter a number"
read number
value=$(expr $number % 2)
if [ $number = 0 ] 
then echo "So you have entered Zero!"
elif [ $value = 0 ] 
then echo "So you have entered Even!"
elif [ $value = 1 ] 
then echo "So you have entered Odd!"
else 
echo "Wrong Number!!!"
fi