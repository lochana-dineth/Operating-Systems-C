#!/bin/bash
#Activity 03: Write a shell script called "myCal", using conditional statements to perform the basic math operations given below. Hint: Read two integers and operator as inputs to the script.

#Turn off shell globbing will help with using '*'
set -f

clear

echo 'Enter First Number'
read num_a
echo 'Enter Second Number'
read num_b

addition=$(expr $num_a + $num_b)
substraction=$(expr $num_a - $num_b)
multipication=$(expr $num_a * $num_b)
division=$(expr $num_a / $num_b)

echo "Multipcation is $addition"
echo "Substration is $substraction"
echo "Multipication is $multipication"
echo "Division is $division"

