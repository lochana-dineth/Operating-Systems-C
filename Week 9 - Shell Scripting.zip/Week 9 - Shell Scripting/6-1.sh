#!/bin/bash
# This program calculate the sum of 1 to 10
max=5

for((n=1; n<=$max; n++)) #for loop
do
    for((j=1; j<=$n; j++)) #Second for loop
    do
    echo -n $n
    done

    printf "\n"
    #Printf works better than echo for dealing with values like this.

done