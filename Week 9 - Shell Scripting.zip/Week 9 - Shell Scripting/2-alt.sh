# -eq for equal -gt for greater than -lt for less than
#If then in Bash
echo "Enter 0 or 1"
read number

if [ $number -eq 0 ] 
then echo "So you have entered Zero!"
elif [ $number -gt 0 ] 
then echo "So you have entered Positive Number!"
elif [ $number -lt 1 ] 
then echo "So you have entered Negative Number!"
else 
echo "Wrong Number!!!"
fi

