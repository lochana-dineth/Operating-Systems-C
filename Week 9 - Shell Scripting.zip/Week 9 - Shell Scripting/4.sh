#!/bin/bash
# This program read command-line arguments
# Basically this will count the number of parameters!

if [ $# -ge 2 ]
then
 echo "Valid Usage"
else
 echo "Invalid Usage"
 exit 1
fi
echo "Script name is $0"
echo "Number of positional parameters: $#"
echo "First positional parameter is $1"
echo "Second positional parameter is $2"