#!/bin/bash

#Activity 07: Write Script to find out biggest number from given three numbers. Numbers are supplies as command line argument. Print error if sufficient arguments are not supplied.

#Get numbers as command line arguments!

if [ $# -lt 3 ]
then
    printf "Incorrect number of Arguments\n" 
    exit 1
else
    printf "Correct number of Arguments\n"
fi

num1=$1
num2=$2
num3=$3
max=0

if [ $num1 -ge $num2 ]
then
max=$num1
else
    max=$num2
fi

if [ $max -ge $num3 ] 
then
    printf "\n"
else
    
    max=$num3
fi

printf "Maximum value is $max\n"

