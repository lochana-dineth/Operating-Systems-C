#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

void *BusyWork(void *null)
{
 int i;
 double result=0.0;
 for (i=1; i<=100000; i++)
 {
 result = result + i;
 }
 printf("Thread result = %e\n",result); //%e is used to represent large numbers

 pthread_exit(NULL);
}


int main()
{

 pthread_t thread1;
 pthread_attr_t attr;
 int rc, t=1;
 void *status;

 pthread_attr_init(&attr);
 pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
 printf("Creating thread %d\n", t);

 rc = pthread_create(&thread1, &attr, BusyWork, NULL);

 if (rc)
 {
 printf("ERROR; return code from pthread_create() is %d\n", rc);
 exit(-1);
 }

 pthread_attr_destroy(&attr);
 rc = pthread_join(thread1, &status);
 if (rc)
 {
 printf("ERROR return code from pthread_join() is %d\n", rc);
 exit(-1);
 }
 printf("Completed join with thread %d status=%ld\n",t,(long)status);

 pthread_exit(NULL);
}
