//To compile we need to use gcc -o 1 1.c -l pthread

#include<stdio.h>
#include<pthread.h>
#include<stdlib.h> //We need this for exit command.
void *sayHello(void *threadid);

int main()
{
    pthread_t t1; //Pthread type
    int rc;
    int t=1000;

    printf("This is my main method before creating the thread %d\n",t);

    //Instead of null we use '\0'
    rc = pthread_create(&t1,'\0',sayHello,(void *)(size_t)t);

    if(rc)
    {
        printf("Cannot create the thread. Error Code %d\n",rc);
        exit(-1); //Forceful exit, not Graceful.
    }

    pthread_exit('\0');
    return 0;
}

//Creating the required method!

void *sayHello(void *threadid)
{
    int tid;
    tid=(size_t)threadid;
    printf("Saying hello from Thread number %d\n", tid);
    pthread_exit('\0');
}