#include<stdio.h>
#include<unistd.h>
int main()
{
 printf("Child Process ID is: %d\n", getpid());
 printf("Parent process ID is: %d\n", getppid());
 sleep(30); /* sleeps for 30 seconds */
 printf("I am awake.\n");
 return 0;
}
