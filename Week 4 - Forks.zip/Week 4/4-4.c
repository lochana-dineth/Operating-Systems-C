#include <sys/types.h>
#include<stdio.h>
#include<unistd.h>

int main()
{
int i=0, j=0, pid;
pid = fork();
if (pid == 0)
{
 for(i=0; i<5000000; i++) /* you may need to increase the iteration
numbers depending on how fast the machine is. */
printf("Child: %d\n", i);
}
else
{
for(j=0;j<5000000;j++)
printf("Parent: %d\n",j);
}
}


