#include <unistd.h>
extern char **environ;
#include <stdio.h>

void main()
{
execl("/bin/sleep", "sleep","10",  (char *) NULL);
printf("What happened?");

}
