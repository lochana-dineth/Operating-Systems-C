#include <sys/types.h>
#include<stdio.h>
#include<unistd.h>
int main()
{
        int i = 9999;
        while (i<9999)
        {
                fork();
                i = i + 1;
        }



}

