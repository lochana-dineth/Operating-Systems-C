#include <sys/types.h>
#include<stdio.h>
#include<unistd.h>
int main()
{
int ret;
ret = fork();

if (ret == 0) /*add code here for the parent and child to run the proper statements*/
{
	/* this is the child process */
	printf("The child ret value is %d\n", ret);
	printf("The child process ID is %d\n", getpid());
 	printf("The child’s parent process ID is %d\n", getppid());
}

else
{
/* this is the parent process */
	        printf("The Parent ret value is %d\n", ret);
	printf("The parent process ID is %d\n", getpid());
 	printf("The parent’s parent process ID is %d\n", getppid());
}

sleep(20);
}
