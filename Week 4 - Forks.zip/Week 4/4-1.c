#include <sys/types.h>
#include<stdio.h>
#include<unistd.h>
int main()
{
	fork();
	fork();
	fork();
	printf("Child PID %d and Parent PPID is %d\n",getpid(), getppid());
	sleep(30);
	return 0;

}	
