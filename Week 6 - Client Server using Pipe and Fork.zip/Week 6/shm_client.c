#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

// To create a Shared Memory we need a size for it, instead of creating an Int Value, we can create a Macro PreProcessor. It is 27 bytes.
#define SHMSZ 27

int main()
{
    //Temp Variable to Store a Char
    char c;
    //Return value given after creating a SM
    int shmid;
    //Key used to identify it
    key_t key;
    //Memory locations
    char *s, *shm;

    //Hardcode the Key. We need to remember this key because we need it to access the shared memory. Or we can use the 'ftok' library
    key = 5678;

    //Create if to validate for errors. IPC_CREAT to create IPC_EXCL to evaluate
    //shmid = shmget(key, SHMSZ, IPC_CREAT | 0666);
    // '|' is the pipeline operator
    if ((shmid = shmget(key, SHMSZ, 0666))<0)
    {
        perror("Cannot Create Shared Memory!\n");
        exit (1);  
    }

    //accessing the shared memory.
    //shm = shmat(shmid, NULL,0);
    if((shm = shmat(shmid, '\0',0))==(char *)-1) 
    {
        perror("Cannot attach! \n");
        exit (1);
    }

    for(s=shm; *s!= '\0';s++)
    {
        putchar(*s);
        
    }
    *shm = '*';

    return 0;
}